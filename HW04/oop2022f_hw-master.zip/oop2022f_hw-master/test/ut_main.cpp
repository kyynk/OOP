#include <gtest/gtest.h>

#include "../src/drink.h"

#include "ut_topping.h"

int main(int argc, char *argv[]) {
	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
