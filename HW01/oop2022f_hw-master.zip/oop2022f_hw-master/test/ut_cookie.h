#include "../src/cookie.h"

// A single test case has the following form:
//
// TEST(TestSuiteName, TestName) {
//   ... test body ...
// }