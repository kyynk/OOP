#include <iostream>
// using namespace std;

std::string print()
{
    return "Hello World";
}