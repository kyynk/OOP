#include <bits/stdc++.h>
#include "../src/drink.h"

/* Place some test here */
/* TEST(GroupName, TestName){} */
