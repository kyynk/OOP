#include <string>

class Drink{
public:
    /* The constructor of the Drink. */
    Drink(std::string name, double sweetness_level){

    }
    /* The destructor of the Drink. */
    ~Drink(){

    }
    /* Return the name of drink. */
    std::string getName(){

    }
    /* Return the level of sweetness. */
    double getSweetnessLevel(){

    }
    /* Add a topping to the drink. */
    void addTopping(std::string topping){

    }
    /* Get the topping of drink by index, the index is determine by the order of topping added and start from 0. */
    std::string getToppingByIndex(int index){

    }
    /* Get the count of topping in drink. */
    int getToppingCount(){

    }
private:
    /* Put some attribute on here if necessary. */
};
