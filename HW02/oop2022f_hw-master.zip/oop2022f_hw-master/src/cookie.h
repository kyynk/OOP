#ifndef COOKIE_H
#define COOKIE_H

int check_x(bool** grid){
    /* Return the x-coordinate of the lastest of cookie. */
}

int check_y(bool** grid){
    /* Return the y-coordinate of the lastest of cookie. */
}

int print_grid(bool** grid){
    /* Print the grid you input. */
    /* Implement this function if necessary, it can help you to check your grid is correct or not. */
}

void placeTop(bool** grid){
    /* Get the coordinate of the cookie which place lastest from grid. */
    /* You can implement check_x(), check_y() above to get the x, y of the lastest cookie you place. */
    int x = check_x(grid);
    int y = check_y(grid);
    
    /* Check when you place cookie, it will out of bound or not. */
    /* ... */

    /* Place cookie from the top of current cookie. */
}

void placeRight(bool** grid){
    /* Get the coordinate of the cookie which place lastest from grid. */
    int x = check_x(grid);
    int y = check_y(grid);

    /* Check when you place cookie, it will out of bound or not. */

    /* Place cookie from the right of current cookie. */
}

int calcRow(bool** grid, int row){
    /* Calculate the count of cookie on the specific row */
}

int calcColumn(bool** grid, int column){
    /* Calculate the count of cookie on the specific column */
}

#endif
