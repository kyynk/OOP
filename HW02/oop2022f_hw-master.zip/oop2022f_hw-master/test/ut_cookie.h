#include <bits/stdc++.h>
#include "../src/cookie.h"

/* The function help you to create the empty grid. */
/* You can use this function or create by yourself. */
bool** create_grid(){
    bool** array = new bool*[10];
    for(int i = 0; i < 10; i++){
        array[i] = new bool[10];
        for(int j = 0; j < 10; j++){
            array[i][j] = false;
        }
    }
    return array;
}

/* The function help you to delete the grid. */
/* You should implement this by yourself. */
void delete_grid(bool** array){

}

/* Add some test in here. */

/* 
TEST(Cookie, SomeTest){
    ...
}
*/
